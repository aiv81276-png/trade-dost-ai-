# Trade Dost AI — starter backend

This is a starter project, not a deployed public app. It connects a chart screenshot upload to the OpenAI Responses API using image input.

## Run locally

1. Install Node.js 20+.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and put your secret API key in `.env`.
4. Start with `npm start`.
5. Open `http://localhost:3000` in your browser.

Never put your API key in HTML/JavaScript sent to the browser. Keep `.env` private and do not upload it to GitHub. Add `.env` to `.gitignore`.

## Included
- `server.js`: Express endpoint `POST /api/analyze`, validates PNG/JPG/WEBP upload, calls OpenAI vision.
- `public/index.html`: mobile-friendly upload page calling the backend.
- `GET /api/health`: reports whether the server has an API key configured (does not reveal it).

## Before public launch
Add real user authentication, rate limits, abuse prevention, logging controls, privacy/retention policy, secure hosting, HTTPS, payment integration if needed, and legal/regulatory review. Restrict allowed origins and add monitoring. Do not rely on screenshot-only AI analysis for trading decisions.

The API call uses the Responses API image input format described in OpenAI's official image/vision docs: https://developers.openai.com/api/docs/guides/images-vision
